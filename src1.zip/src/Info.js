import React, {Component} from 'react';

class Info extends Component{
    render(){
        console.log(this.props);
        return(
            <div>info for {this.props.match.params.code1}</div>
        )
    }
}
export default Info;