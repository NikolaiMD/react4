import React, {Component} from 'react';
import {BrowserRouter as Router, Link, Route} from 'react-router-dom';
import Info from './Info.js';


class FooterNav extends Component{
    render(){
        return(
            <Router>
                <div>
                <Link to="/info/contacts">Contacts</Link>
                <br/>
                <Link to="/info/terms">Terms</Link>
                </div>
                <Route path="/info/:code1" component={Info}/>
            </Router>
        )
    }
}

export default FooterNav;