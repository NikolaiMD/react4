import React from 'react';
import MainNav from './MainNav.js';
import FooterNav from './FooterNav.js';



function App() {
  return (
    <div>
      <MainNav/>
      <FooterNav/>
    </div>
  );
}

export default App;
