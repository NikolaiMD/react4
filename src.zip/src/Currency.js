import React, {Component} from 'react';
import axios from 'axios';
const KEY = "a95f86ba6e1a66f31205337bdead6576";
const URL =`http://data.fixer.io/api/latest?access_key=${KEY}`;
class Currency extends Component{
    constructor(){
        super();
        this.state={rates: {}};

        // componentDidMount()
        var rate;
        var _this = this;
        axios.get(URL)
            .then(function(response){
                let code = _this.props.match.params.code;
                console.log(response);
                /*rate =*/ /*[code.toUpperCase()]*/;
                // console.log(rate);  
                _this.setState({rates: response.data.rates})
            });
    }
    render(){
        let code = this.props.match.params.code;
        
        
        return(
            <div>info for {code} {this.state.rates[code.toUpperCase()]}</div>
        )
    }
}
export default Currency;