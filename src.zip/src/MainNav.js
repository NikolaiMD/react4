import React, {Component} from 'react';
import {BrowserRouter as Router, Link, Route} from 'react-router-dom';
import Currency from './Currency.js'

class MainNav extends Component{
    render(){
        return (
            <Router>
            <nav>
                <Link to="/currency/euro">EUR</Link>
                <br/>
                <Link to="/currency/usd">USD</Link>
                <br/>
                <Link to="/currency/gbp">POUND</Link>
            </nav>
            <hr/>
            <Route path="/currency/:code" component={Currency}/>
            {/* <Route path="/r2" exact component={Currency}/>
            <Route path="/r3" exact component={Currency}/> */}
            </Router>
        )
    }
}
export default MainNav;